local drop_words =
{ 	"示~例~",
}
return drop_words